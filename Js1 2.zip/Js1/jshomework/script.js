const people = {
  friends: []
};

const friend1 = {
  firstName: "Sandra",
  lastName: "Andrade",
  id: 123
};

const friend2 = {
  firstName: "Heide",
  lastName: "Ribeiro",
  id: 234
};

const friend3 = {
  firstName: "Marina",
  lastName: "Nascimento",
  id: 345
};

people.friends.push(friend1);
people.friends.push(friend2);
people.friends.push(friend3);

let output = '';
for (const friend of people.friends) {
  output += `First Name: ${friend.firstName}, Last Name: ${friend.lastName}, ID: ${friend.id}\n`;
}

document.getElementById('output').textContent = output;
