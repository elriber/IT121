const myArr = ["Rock", "Paper", "Scissors"];

let computer = Math.floor(Math.random() * 3);
let player = Math.floor(Math.random() * 3);
let message = "player " + myArr[player] + " vs computer " + myArr[computer] + " ";

if (player === computer) {
  message += "It is a tie";
} else if (
  (player === 0 && computer === 2) ||
  (player === 1 && computer === 0) ||
  (player === 2 && computer === 1)
) {
  message += "Player Wins";
} else {
  message += "Computer Wins";
}

console.log(message);
