// Recursive function that counts up to 10
function counter(i) {
  if (i >= 10) {
    return;
  }
  console.log(i);
  counter(i + 1);
}

// Invoke the recursive function with different start numbers
counter(0);
counter(5);

// Functions to output values one, two, and three
const one = () => console.log('one');
const two = () => console.log('two');
const three = () => {
  console.log('three');
  one();
  two();
};

// Invoke the functions in a specific order
three();

// Function to output the word four and invoke function one after 0 milliseconds
const four = () => {
  console.log('four');
  setTimeout(one, 0);
  three();
};

// Invoke the fourth function
four();
